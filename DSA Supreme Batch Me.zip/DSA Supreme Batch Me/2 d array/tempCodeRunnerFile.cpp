// Algirithmn for transpose
// for (int  i = 0; i < 3; i++)
// {
//     for (int  j = 0; j < 3; j++)
//     {
//     //    Swaping 
//     int b=a[j][i];
//     a[j][i]=a[i][j];
//     a[i][j]=b;
//     }}