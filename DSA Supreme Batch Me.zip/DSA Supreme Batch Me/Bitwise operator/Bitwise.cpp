#include<iostream>
using namespace std;
int main ()
{
bool a=true,b=false;
cout<<(a|b)<<endl;
cout<<(a&b)<<endl;
cout<<(a^b)<<endl;
cout<<(~a)<<endl;
cout<<(5|10)<<endl;
cout<<(5&10)<<endl;

 return 0;
}