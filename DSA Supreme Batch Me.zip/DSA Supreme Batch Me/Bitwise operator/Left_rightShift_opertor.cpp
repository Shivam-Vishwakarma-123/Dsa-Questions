#include<iostream>
using namespace std;
int main ()
{
int a=5;
// In case of left shift the digit is multiplied by 2
a=a<<1;
cout<<a<<endl;
// a=a<<-1;
// GArbage output


// Output is 10
// In case of left shift the digit is divide by 2 isme catch he 
// int b=10;
// ;
// cout<<(b>>1);
// output =5
// But agar negative number lete 
int b=-5;
cout<<(b>>+1); 


 return 0;
}