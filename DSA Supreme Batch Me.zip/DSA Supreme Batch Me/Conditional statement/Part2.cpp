#include<iostream>
using namespace std ;
int main(){
//Making input variable 
int bro_num;
// Taking input from user 
cout<<"Enter no of brother: \nMaximum no of brother should be less than two \n";
cin>>bro_num;
if(bro_num==0){
    cout<<"Baat ban jayegi \n";

}else {
    cout<<"Baat nhi banegi bhai \n";
}



}