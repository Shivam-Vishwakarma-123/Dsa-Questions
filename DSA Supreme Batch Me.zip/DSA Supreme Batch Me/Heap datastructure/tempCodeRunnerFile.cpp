
for(int i=0;i<sheet.size();i++){
    cout<<sheet[i].name<<" "<<sheet[i].marks<<endl;
}

 return 0;
}