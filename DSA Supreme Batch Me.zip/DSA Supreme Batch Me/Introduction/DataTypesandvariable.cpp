#include<iostream>
using  namespace std;
int  main()
{
    int a=5;
    short c=5;
    float b=5.2;
    double g=5.2;
    long d=5;
    long long e=5;
    char f='5';
    bool h=1;


     cout<<sizeof(a)<<endl;
     cout<<sizeof(c)<<endl;
     cout<<sizeof(b)<<endl;
     cout<<sizeof(g)<<endl;
     cout<<sizeof(d)<<endl;
     cout<<sizeof(e)<<endl;
     cout<<sizeof(f)<<endl;
     cout<<sizeof(h)<<endl;

}