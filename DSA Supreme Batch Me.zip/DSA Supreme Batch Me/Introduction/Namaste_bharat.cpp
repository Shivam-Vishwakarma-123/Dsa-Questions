#include<iostream>
using namespace std;
int main(){
    cout<<"Namaste Bharat ";
    cout<<2<<endl;
    cout<<"2\n";
    cout<<'2';
    return 0;
}