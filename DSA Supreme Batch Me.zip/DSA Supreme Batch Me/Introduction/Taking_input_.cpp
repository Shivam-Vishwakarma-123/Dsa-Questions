#include<iostream>
int main(){
    using namespace std;
    int a;
    cout<<"Enter a number\n";
    cin>>a;
    cout<<"You entered "<<a;
    bool b=true;
    cout<<endl<<b<<endl;
    return 0;
}