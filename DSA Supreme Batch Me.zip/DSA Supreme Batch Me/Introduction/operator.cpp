#include<iostream>
using namespace std; 
int main(){
    int a=5,b=3;
    //Arithematics operator 
    cout<<a+b<<endl;
    cout<<a-b<<endl;
    cout<<a*b<<endl;
    cout<<(double)a/b<<endl;
    cout<<a%b<<endl;
    return 0;
}
//for operters in c++ visit 
//https://www.geeksforgeeks.org/operators-in-cpp/