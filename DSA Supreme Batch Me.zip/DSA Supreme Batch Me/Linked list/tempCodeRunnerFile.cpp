head=ReverseinKgroup(head,3);
// print(head);