#include<iostream>
using namespace std;
int main(){
    // case 1
    // int n;
    // if(cin>>n){
    //     cout<<"Love babbar"<<endl;
    // }
int n=50;
    if(cout<<n){
        cout<<"Love babbar\n";
    }
}