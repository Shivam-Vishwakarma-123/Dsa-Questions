#include<iostream>
using namespace std;
int main(){


    //What are the condition are require to fill in for loop 

    //case 1 initialising i before for loop 
//     int i=0;
//     for(;(i<=10);i++){
//       cout<<i<<endl;
//     }
// } same output 



// case 2 defing condition inside the loop   ///// no condition 
   int j=0;
   for(;;){
if(j<10){
  cout<<j<<endl;
  j=j+1;
}

   }}