#include<iostream>
using namespace std;
int main(){
// From Row persceptive 
    for(int row=0;row<3;row++ )//For rows 
    {for(int col=0;col<5;col++) //for column 
    {
cout<<" * ";
    }
cout<<endl;
    }










}