#include<iostream>
using namespace std ;
// Printing square pattern 

int main(){
    for(int row=0;row<20;row++){
        for(int col=0;col<20;col++){
            cout<<" * ";
        } cout<<endl;
    }
}